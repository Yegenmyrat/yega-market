YEGA MARKET — mugt başlangyç web nusgasy

Içinde:
- index.html: telefonda we kompýuterde işleýän bir sahypalyk dükan dizaýny
- Kategoriýalar, gözleg, sebet we synag sargyt formasy
- Hiç hili tölegli kitaphana ýa-da API gerek däl

IŞE GIRIZMEK:
1. ZIP faýly aç.
2. index.html faýlyna basyp brauzerde aç — ýerli synag üçin.
3. Internetde mugt ýerleşdirmek üçin GitHub hasabynda täze repository aç.
4. index.html faýlyny repository-ä ýükle.
5. Repository Settings -> Pages -> Deploy from a branch -> main / root -> Save.
6. GitHub Pages berýän mugt web salgysyny ulan.

Möhüm:
- Bu diňe başlangyç frontend nusgasy. Harytlar we bahalar demo maglumatlarydyr.
- Hakyky töleg, müşderi hasaby, maglumat bazasy, sargyt saklamak we üpjün ediji birikdirilmedi.
- Domen satyn almak hökmany däl; mugt github.io salgysy ulanylyp bilner.
- Töleg geçirmek üçin Shopify ýa-da başga tölegli hyzmat hökmany däl, emma hakyky satuw üçin aýratyn töleg/iberiş çözgüdi gerek bolup biler.
